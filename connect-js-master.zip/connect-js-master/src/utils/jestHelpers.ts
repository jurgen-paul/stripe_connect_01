export const SCRIPT_SELECTOR =
  'script[src^="https://connect-js.stripe.com/v1.0/connect.js"]';

export {};
