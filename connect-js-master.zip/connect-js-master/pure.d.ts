import { LoadConnectAndInitialize } from "./src/shared";

export declare const loadConnectAndInitialize: LoadConnectAndInitialize;
export * from "./types/shared";
